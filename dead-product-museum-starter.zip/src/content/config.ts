import { z, defineCollection } from 'astro:content';

const exhibits = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    years: z.string(), // e.g., "2001–2014"
    cause: z.string(),
    summary: z.string().optional(),
    slug: z.string().optional(),
    brand: z.string().optional(),
    aliases: z.array(z.string()).optional()
  })
});

const brands = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    summary: z.string().optional(),
    founded: z.string().optional(),
    status: z.string().optional()
  })
});

export const collections = { exhibits, brands };
